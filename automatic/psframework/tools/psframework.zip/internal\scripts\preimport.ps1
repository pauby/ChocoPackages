﻿# Load "Environment" variables within the module
. Import-ModuleFile -Path "$($script:ModuleRoot)\internal\scripts\environment.ps1"