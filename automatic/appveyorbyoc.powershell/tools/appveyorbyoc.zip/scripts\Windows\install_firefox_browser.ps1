﻿Write-Host "Installing FireFox..." -ForegroundColor Cyan

choco install firefox

Write-Host "Installed FireFox" -ForegroundColor Green